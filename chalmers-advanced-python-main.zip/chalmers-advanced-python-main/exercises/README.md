# Advanced Python, Exercises

The exercises are not compulsory, but strongly recommended.
If you are not able to attend the class, you should try and do them yourself!


## On exercise 1

Here you will need to do some Python programming after just one lecture on the course.
If you have taken the introduction course in Python, this should be easy.
If you have not, there can be quite some need for reading documents and trying out solutions.
Just some hints for what constructs and functions can be useful:

- Question 1: ``def``,  ``input``, ``if else``, s``[0]``,  ``print()``
- Question 2: also ``while``, ``return``, ``dict``, d``[key]``, ``split()``
- Question 3: also ``len()``, s``[m:n]``, ``append()``, ``join()``
- Question 4: also ``for``, ``get()`` 

